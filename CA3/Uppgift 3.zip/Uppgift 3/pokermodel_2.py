""" Oliver Johansson and Anton Sandberg """
""" Computer Assignment 3 """
""" Group 7 """
from PyQt5.QtCore import*
import CardLib
import time

class Player(QObject):
    """ Creating the class for the player(s) that starts the player off """

    def __init__(self, name, money):
        self.name = name
        self.money = money
        self.hand = CardLib.Hand()
        self.bet = 0

class TexasHoldemModel(QObject):

    upd_cards = pyqtSignal()
    upd_data = pyqtSignal()
    WinGame = pyqtSignal()
    flip = pyqtSignal()

    def __init__(self, name, money):
        super().__init__()

        self.player1name = name[0]
        self.player2name = name[1]
        self.player1money = money[0]
        self.player2money = money[1]
        # Känns som dessa borde sättas på ställena de ska vara på snarare än i början

        self.amount_table = 0    #
        self.players = [Player(self.player1name, self.player1money), Player(self.player2name, self.player2money)]
        self.pot = 0
        self.turn = 0                      # Decides whos turn it is, 0 = P1, 1 = P2
        self.sblind = 50
        self.bblind = 100
        self.players[0].bet = self.sblind  #Player1 starts with small blind
        self.players[1].bet = self.bblind  #Player2 with big blind
        self.round_turn = 0                # decides who starts the next round
        self.check_count = 0               # Counts if both players check
        self.round_winner = "TBD"
        self.Winner = 0                    # The final winner


        self.RoundWin = 0       # winner of last round
        self.activebet = 0      # should show current bet from highest bet
        self.turnstring = [self.players[0].name, self.players[1].name]      # showing players name as it's his/her turn
        self.RoundTurn = 0  # who starts the round
        self.all_in = 0     # if a player goes all in
        self.finalpot = 0   # To show winning pot
        self.displaywinninghand = "TBD"

        self.checkplayer = ["{} Checks".format(self.players[0].name), "{} Checks".format(self.players[1].name)]
        self.checkplayerdisplay = ""
        self.playersname = ""

        self.players[0].money += - self.players[0].bet
        self.players[1].money += - self.players[1].bet

        # variable for checking twice in a row
        self.c = 0

        # adds the bet to the pot
        self.pot += self.players[0].bet + self.players[1].bet

        self.newRound()


    def WhoWon(self):
        """ A function that checks whos hand is better, who won this round, uses our earlier defined PokerHand
        to determine a winner"""

        check_hand1 = self.players[0].hand.best_poker_hand(self.table.table) # Adding together cards on hand with table
        check_hand2 = self.players[1].hand.best_poker_hand(self.table.table) # cards

        # testar att skriva ut vad man vann
        self.printhandcheck = [self.players[0].hand.best_poker_hand(self.table.table), self.players[1].hand.best_poker_hand(self.table.table)]

        if check_hand1 > check_hand2:
            self.WinnerofRound(0)

        elif check_hand1 < check_hand2:
            self.WinnerofRound(1)

        elif check_hand1 == check_hand2:
            if check_hand1.value > check_hand2.value:
                    self.WinnerofRound(0)

            elif check_hand1.value < check_hand2.value:
                    self.WinnerofRound(1)

            else:
                self.draw()





    def WinnerofRound(self, RoundWinner):
        """ Checks the winner of the round, input is either 0 or 1 depending on if it's player 1 or 2 """

        self.table.table.clear()
        self.players[RoundWinner].money += self.pot
        self.finalpot = self.pot
        self.round_winner = self.players[RoundWinner].name  # For the display of winner
        self.displaywinninghand = "{} Folded".format(self.players[self.turn].name)

        if self.amount_table == 5 and self.players[0].bet == self.players[1].bet:
            self.displaywinninghand = CardLib.HandRanks(self.printhandcheck[RoundWinner].ranking).name

        if self.players[0].money <= 0:
            self.Winner = 1                  #For the display of game winner
            self.WinGame.emit()

        elif self.players[1].money <= 0:
            self.Winner = 0
            self.WinGame.emit()

        self.upd_data.emit()
        self.reset()




    def bet(self, amount):
        """ The bet function, needs to be able to check what the user is typing in the input
        aswell as know whos turn it is """
        self.amount = amount
        if self.turn == 0:
            self.players[self.turn].bet += self.amount
            self.players[self.turn].money += - self.amount
            self.pot += self.amount
            self.turn = 1

        elif self.turn == 1:
            self.players[self.turn].bet += self.amount
            self.players[self.turn].money += - self.amount
            self.pot += self.amount
            self.turn = 0

        self.upd_data.emit()

    def draw(self):
        """ Method that is called when the current round concludes in a draw """

        for player in self.players:
            player.money += int(self.pot/2)

        self.round_winner = "Draw"
        self.finalpot = int(self.pot/2)
        self.displaywinninghand = CardLib.HandRanks(self.printhandcheck[0].ranking).name
        self.reset()

    def check_fold(self):
        """ Function to check or fold dependant on if the user need to call to be able to continue playing the round """
        if self.players[self.turn].bet >= max(self.players[0].bet, self.players[1].bet):
            self.c += 1
            if self.turn == 0:
                self.checkplayerdisplay = self.checkplayer[0]
                self.turn = 1
                if self.c == 2:
                    self.CardtoTable()
                    self.c = 0
                    self.checkplayerdisplay = ""
            elif self.turn == 1:
                self.checkplayerdisplay = self.checkplayer[1]
                self.turn = 0
                if self.c == 2:
                    self.CardtoTable()
                    self.c = 0
                    self.checkplayerdisplay = ""
        else:
            if self.turn == 0:
                self.WinnerofRound(1)
            else:
                self.WinnerofRound(0)

        self.upd_data.emit()


    def call(self):
        """ Call function, needs to check how much the player needs to put in to be able to call aswell as if the
         player can afford to """
        call_money = abs(self.players[1].bet - self.players[0].bet)
        if self.turn == 0 and self.players[0].bet < self.players[1].bet:
            if self.players[0].money >= call_money:
                self.players[0].bet += call_money
                self.players[0].money += - call_money
                self.pot += call_money
                self.CardtoTable()
                self.turn = 1
                self.players[0].bet = 0
                self.players[1].bet = 0


        elif self.turn == 1 and self.players[1].bet < self.players[0].bet:
            if self.players[1].money >= call_money:
                self.players[1].bet += call_money
                self.players[1].money += - call_money
                self.pot += call_money
                self.CardtoTable()
                self.turn = 0
                self.players[1].bet = 0
                self.players[0].bet = 0
            else:

                self.players[1].bet += self.players[1].money
                self.pot += self.players[1].money
                self.players[1].money += - self.players[1].money
                self.CardtoTable()
                self.turn = 0
                self.players[1].bet = 0
                self.players[0].bet = 0


        self.upd_data.emit()



    def CardtoTable(self):
        """ Function to insert more card to the table, 3 the first round, 1 and 1 more the other 2, need to call
        on WhoWon when the river card is out and both players made their turns """
        card = self.Deck.card()

        if self.amount_table == 0:

            self.table.new_card(card)
            card = self.Deck.card()
            self.table.new_card(card)
            card = self.Deck.card()
            self.table.new_card(card)
            self.upd_cards.emit()
            self.amount_table = 3
            self.c = 0

        elif self.amount_table == 3:
            card = self.Deck.card()
            self.table.new_card(card)
            self.upd_cards.emit()
            self.amount_table = 4
            self.c = 0

        elif self.amount_table == 4:
            card = self.Deck.card()
            self.table.new_card(card)
            self.upd_cards.emit()
            self.amount_table = 5
            self.c = 0

        elif self.amount_table == 5:
            self.c = 0
            self.WhoWon()


    def newRound(self):
        """ The function that resets the round to able to start the next round """
        self.Deck = CardLib.StandardDeck()
        self.Deck.shuffle()
        self.players[0].hand.cards.clear()
        self.players[1].hand.cards.clear()

        for i in self.players:
            for j in range(2):
                newcard = self.Deck.card()
                i.hand.add_card(newcard)

        self.table = CardLib.Table()
        self.table.table.clear()
        self.amount_table = 0

        self.upd_cards.emit()
        self.flip.emit()


    def reset(self):

        self.pot = 0
        if self.RoundTurn == 0:
            self.turn = 1
            self.RoundTurn = 1
            self.players[self.turn].bet = self.sblind
            self.players[self.turn-1].bet = self.bblind
            self.pot += self.players[0].bet + self.players[1].bet
        else:
            self.RoundTurn = 0
            self.turn = 0
            self.players[self.turn].bet = self.sblind
            self.players[self.turn + 1].bet = self.bblind
            self.pot += self.players[0].bet + self.players[1].bet

        if self.players[0].money < self.bblind:
            self.players[0].bet = self.players[0].money
            self.players[1].bet = int(self.players[0].money/2)
            self.turn = 1

        elif self.players[1].money < self.bblind:
            self.players[1].bet = self.players[1].money
            self.players[0].bet = int(self.players[1].money/2)
            self.turn = 0


        self.players[0].money += - self.players[0].bet
        self.players[1].money += - self.players[1].bet

        self.all_in = 0
        self.c = 0

        self.upd_data.emit()
        self.newRound()

    def NewPokerGame(self):

        self.players = [Player(self.player1name, self.player1money), Player(self.player2name, self.player2money)]
        self.reset()
